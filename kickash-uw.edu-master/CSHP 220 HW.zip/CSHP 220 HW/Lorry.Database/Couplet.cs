﻿using System;
using System.Collections.Generic;

namespace Lorry.Database
{
    public partial class Couplet
    {
        public int CoupletId { get; set; }
        public string CoupletContent { get; set; }
        public string CoupletRhyme { get; set; }
    }
}
